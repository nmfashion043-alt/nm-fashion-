NM FASHION — GitHub Pages fixed package

Upload ALL of these files to the ROOT of your GitHub repository:
index.html
images/logo.png
images/product-01.png through images/product-09.png

Important: delete/replace the old index.html and old site files first. Do not upload this ZIP itself as the website.

Then GitHub: Settings > Pages > Deploy from a branch > main > /(root) > Save.

If the old page still appears, open the URL in an Incognito/Private tab or hard-refresh after GitHub Pages redeploys.
