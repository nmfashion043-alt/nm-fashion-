NM FASHION — SINGLE-FILE FINAL WEBSITE

This version prevents missing product images on GitHub Pages.
All 9 original product catalogue images and the NM FASHION logo are embedded inside index.html.

UPLOAD:
1. Extract this ZIP.
2. Upload ONLY index.html to the ROOT of your GitHub repository.
3. Enable GitHub Pages: Settings > Pages > Deploy from a branch > main > /(root) > Save.

Business: NM FASHION
Khalashpir Bazar, Pirganj, Rangpur, Bangladesh
Phone/WhatsApp: 01321107043
